<?php
/**
 * PDO connection singleton.
 * Update the DSN, username and password to match your Contabo VPS MySQL credentials.
 */
class DB {
    private static $pdo = null;

    public static function conn() {
        if (self::$pdo === null) {
            $dsn      = 'mysql:host=localhost;dbname=narrid_prelaunch;charset=utf8mb4';
            $user     = 'db_user';     // <-- CHANGE THIS
            $password = 'db_password'; // <-- CHANGE THIS

            $options  = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            self::$pdo = new PDO($dsn, $user, $password, $options);
        }
        return self::$pdo;
    }
}
?>
