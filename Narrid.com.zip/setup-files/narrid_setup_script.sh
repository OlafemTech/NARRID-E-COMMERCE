#!/bin/bash

# === Step 1: Update & Install Required Packages ===
sudo apt update && sudo apt upgrade -y
sudo apt install -y apt-transport-https ca-certificates curl software-properties-common unzip git ufw

# === Step 2: Install Docker & Docker Compose ===
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
sudo apt update
sudo apt install -y docker-ce docker-compose
sudo usermod -aG docker ${USER}

# === Step 3: Set Up Laravel Project Structure ===
mkdir -p /var/www/narrid
cd /var/www/narrid

# === Step 4: Create Docker Compose File ===
cat <<EOF > docker-compose.yml
version: '3.8'
services:
  app:
    image: laravelphp/php-fpm
    container_name: laravel_app
    restart: unless-stopped
    working_dir: /var/www/html
    volumes:
      - ./:/var/www/html
    networks:
      - narrid

  webserver:
    image: nginx:alpine
    container_name: nginx_web
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./:/var/www/html
      - ./nginx/conf.d:/etc/nginx/conf.d
      - ./certbot/www:/var/www/certbot
      - ./certbot/conf:/etc/letsencrypt
    networks:
      - narrid
    depends_on:
      - app

  mysql:
    image: mysql:5.7
    container_name: mysql_db
    restart: unless-stopped
    ports:
      - "3306:3306"
    environment:
      MYSQL_DATABASE: laravel
      MYSQL_ROOT_PASSWORD: secret
    volumes:
      - dbdata:/var/lib/mysql
    networks:
      - narrid

  phpmyadmin:
    image: phpmyadmin/phpmyadmin
    restart: always
    ports:
      - "8080:80"
    environment:
      PMA_HOST: mysql
    networks:
      - narrid

networks:
  narrid:

volumes:
  dbdata:
EOF

# === Step 5: Setup NGINX Config Directory ===
mkdir -p nginx/conf.d
cat <<EOF > nginx/conf.d/default.conf
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    root /var/www/html/public;
    index index.php index.html;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location ~ \.php\$ {
        include fastcgi_params;
        fastcgi_pass app:9000;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
    }

    location ~ /\.ht {
        deny all;
    }

    location ~ /.well-known/acme-challenge/ {
        root /var/www/certbot;
        allow all;
    }
}
EOF

# === Step 6: Download Laravel ===
curl -sS https://getcomposer.org/installer | php
mv composer.phar /usr/local/bin/composer
docker run --rm -v $(pwd):/app composer create-project --prefer-dist laravel/laravel .

# === Step 7: Fix Permissions ===
sudo chown -R $USER:www-data .
sudo chmod -R 775 storage bootstrap/cache

# === Step 8: SSL with Let's Encrypt using Certbot ===
mkdir -p certbot/conf certbot/www
docker run -it --rm   -v "$(pwd)/certbot/conf:/etc/letsencrypt"   -v "$(pwd)/certbot/www:/var/www/certbot"   certbot/certbot certonly   --webroot   --webroot-path=/var/www/certbot   --agree-tos   --no-eff-email   --email your@email.com   -d yourdomain.com -d www.yourdomain.com

# === Step 9: Restart Docker Compose ===
docker-compose down
docker-compose up -d --build

echo "✅ Laravel + Docker + SSL setup complete! Visit http://yourdomain.com"
