#!/bin/bash

# === Step 1: Update System & Install Required Packages ===
sudo apt update && sudo apt upgrade -y
sudo apt install -y apt-transport-https ca-certificates curl software-properties-common unzip git ufw

# === Step 2: Install Docker & Docker Compose ===
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
sudo apt update
sudo apt install -y docker-ce docker-compose
sudo usermod -aG docker ${USER}

# === Step 3: Setup Laravel Project ===
mkdir -p /var/www/narrid
cd /var/www/narrid

# === Step 4: Docker Compose File ===
cat <<EOF > docker-compose.yml
version: '3.8'
services:
  app:
    image: laravelphp/php-fpm
    container_name: laravel_app
    restart: unless-stopped
    working_dir: /var/www/html
    volumes:
      - ./:/var/www/html
    networks:
      - narrid

  webserver:
    image: nginx:alpine
    container_name: nginx_web
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./:/var/www/html
      - ./nginx/conf.d:/etc/nginx/conf.d
      - ./certbot/www:/var/www/certbot
      - ./certbot/conf:/etc/letsencrypt
    networks:
      - narrid
    depends_on:
      - app

  mysql:
    image: mysql:5.7
    container_name: mysql_db
    restart: unless-stopped
    ports:
      - "3306:3306"
    environment:
      MYSQL_DATABASE: laravel
      MYSQL_ROOT_PASSWORD: secret
    volumes:
      - dbdata:/var/lib/mysql
    networks:
      - narrid

  phpmyadmin:
    image: phpmyadmin/phpmyadmin
    restart: always
    ports:
      - "8080:80"
    environment:
      PMA_HOST: mysql
    networks:
      - narrid

networks:
  narrid:

volumes:
  dbdata:
EOF

# === Step 5: NGINX Config ===
mkdir -p nginx/conf.d
cat <<EOF > nginx/conf.d/default.conf
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    root /var/www/html/public;
    index index.php index.html;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location ~ \.php\$ {
        include fastcgi_params;
        fastcgi_pass app:9000;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
    }

    location ~ /\.ht {
        deny all;
    }

    location ~ /.well-known/acme-challenge/ {
        root /var/www/certbot;
        allow all;
    }
}
EOF

# === Step 6: Composer + Laravel Download ===
curl -sS https://getcomposer.org/installer | php
mv composer.phar /usr/local/bin/composer
docker run --rm -v $(pwd):/app composer create-project --prefer-dist laravel/laravel .

# === Step 7: File Permissions ===
sudo chown -R $USER:www-data .
sudo chmod -R 775 storage bootstrap/cache

# === Step 8: SSL Setup (Let's Encrypt) ===
mkdir -p certbot/conf certbot/www
docker run -it --rm   -v "$(pwd)/certbot/conf:/etc/letsencrypt"   -v "$(pwd)/certbot/www:/var/www/certbot"   certbot/certbot certonly   --webroot   --webroot-path=/var/www/certbot   --agree-tos   --no-eff-email   --email your@email.com   -d yourdomain.com -d www.yourdomain.com

# === Step 9: CI/CD Setup (GitHub Actions) ===
mkdir -p .github/workflows
cat <<EOF > .github/workflows/deploy.yml
name: Deploy to Contabo VPS

on:
  push:
    branches:
      - main

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v2

      - name: Copy files to VPS using SCP
        uses: appleboy/scp-action@master
        with:
          host: \$\{{ secrets.VPS_HOST }}
          username: \$\{{ secrets.VPS_USER }}
          key: \$\{{ secrets.VPS_SSH_KEY }}
          source: "."
          target: "/var/www/narrid"

      - name: SSH into VPS and deploy
        uses: appleboy/ssh-action@master
        with:
          host: \$\{{ secrets.VPS_HOST }}
          username: \$\{{ secrets.VPS_USER }}
          key: \$\{{ secrets.VPS_SSH_KEY }}
          script: |
            cd /var/www/narrid
            docker-compose down
            docker-compose up -d --build
EOF

echo "✅ Laravel + Docker + SSL + GitHub CI/CD setup complete!"
